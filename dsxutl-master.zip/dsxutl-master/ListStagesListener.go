/*
	Copyright 2018 Jerome Delvigne

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package main

import (
	"fmt"
	"strings"
	"github.com/jdelvign/dsxparser"
)

type ListStagesListener struct {
	*dsxparser.BaseDSXListener
	identifierListener *IdentifierListener
	jobName string
}

func NewListStagesListener(jobName string) *ListStagesListener {
	l := new(ListStagesListener)
	l.identifierListener = NewIdentifierListener()
	l.jobName = jobName
	return l
}

func (this *ListStagesListener) EnterDsjob(ctx *dsxparser.DsjobContext) {
	
	ctx.Identifier().EnterRule(this.identifierListener)

	if this.identifierListener.value == this.jobName {
		fmt.Printf("%s\n", this.jobName)
		recordsI := ctx.AllDsrecord()
		for _, t := range recordsI {
			record := t.(*dsxparser.DsrecordContext)			
			propertiesI := record.AllProperty()
			nameFound := false
			var stageName string 
			typeFound := false
			for _, p := range propertiesI {
				property := p.(*dsxparser.PropertyContext)
				if strings.Trim(property.Propname().GetText(), "\"") == "Name" {
					stageName = property.Propvalue().GetText()
					nameFound = true
				}
				if strings.Trim(property.Propname().GetText(), "\"") == "OLEType" {
					if strings.Trim(property.Propvalue().GetText(), "\"") == "CCustomStage" {
						typeFound = true
					}
				}
				if (nameFound && typeFound) { break }
			}
			if (nameFound && typeFound) {
				fmt.Printf("+- %s\n", stageName)
			}
		}
	}
}
