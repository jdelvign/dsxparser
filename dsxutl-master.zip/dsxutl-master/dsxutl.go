/*
	Copyright 2018 Jerome Delvigne

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package main

import (
	"flag"
	"fmt"
	"time"
	"github.com/antlr/antlr4/runtime/Go/antlr"
	"github.com/jdelvign/dsxparser"
)

// Check error returned by I/O functions
func check(e error) {
	if e != nil {
			panic(e)
	}
}

type DSXVisitor struct {
	*dsxparser.BaseDSXVisitor
}

func NewDSXVisitor() *DSXVisitor {
	visitor := new(DSXVisitor)
	//visitor.SetSuper(visitor)
	return visitor
}

func (this *DSXVisitor) VisitDsx(ctx *dsxparser.DsxContext) interface{} {
	return this.VisitChildren(ctx)
}

func (this *DSXVisitor) VisitDsjob_content(ctx *dsxparser.DsjobContext) interface{} {
	fmt.Printf("In here: %s\n", ctx.GetText())
	return this.VisitChildren(ctx)
}

// DSXUTL Command
// With ANTLR4 parser
func main() {

	header := flag.Bool("header", false, "Display HEADER informations")
	ljobsPtr := flag.Bool("ljobs", false, "Display a list of all jobs in the specified DSX")
	jobPtr := flag.String("job", "", "Job name for -lstages")
	lstagesPtr := flag.Bool("lstages", false, "Display a list of all stages for the given job in the specified DSX")

	flag.Parse()

	start := time.Now()
	input, err := antlr.NewFileStream(flag.Args()[0])
	check(err)
	lexer := dsxparser.NewDSXLexer(input)
	stream := antlr.NewCommonTokenStream(lexer,0)
	p := dsxparser.NewDSXParser(stream)
	t := time.Now()
	fmt.Printf("Init Elapsed Time: %v\n", t.Sub(start))
	
	if *header {
		start = time.Now()
		p.AddErrorListener(antlr.NewDiagnosticErrorListener(true))
		p.BuildParseTrees = true
		tree := p.Dsx()
		t = time.Now()
		fmt.Printf("p.Dsx() Elapsed Time: %v\n", t.Sub(start))
		antlr.ParseTreeWalkerDefault.Walk(NewHeaderListener(), tree)
	}

	if *ljobsPtr {		
		//tree := p.Dsx()
		//visitor := NewDSXVisitor()
		//visitor.VisitDsx(tree.(*parser.DsxContext))
		start := time.Now()
		p.AddErrorListener(antlr.NewDiagnosticErrorListener(true))
		p.BuildParseTrees = true
		tree := p.Dsx()
		t := time.Now()
		fmt.Printf("p.Dsx() Elapsed Time: %v\n", t.Sub(start))
		antlr.ParseTreeWalkerDefault.Walk(NewJobListener(), tree)
	}

	if *lstagesPtr {
		start := time.Now()
		p.AddErrorListener(antlr.NewDiagnosticErrorListener(true))
		p.BuildParseTrees = true
		tree := p.Dsx()
		t := time.Now()
		fmt.Printf("p.Dsx() Elapsed Time: %v\n", t.Sub(start))
	
		antlr.ParseTreeWalkerDefault.Walk(NewListStagesListener(*jobPtr), tree)
	}
}
